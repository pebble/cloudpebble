#pragma once

const char * world(void);
