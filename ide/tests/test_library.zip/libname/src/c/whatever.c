#include <pebble.h>
#include "whatever.h"

const char * world(void) {
    return "World!";
}
